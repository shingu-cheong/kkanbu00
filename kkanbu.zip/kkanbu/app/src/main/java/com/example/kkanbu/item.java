package com.example.kkanbu;

public class item {
    public int resId;
    String name;
    String gender;
    String ph;

    public item(int resid, String name, String gender, String ph) {
        this.name = name;
        this.gender = gender;
        this.ph = ph;
    }
}
