package com.example.kkanbu.utils;

public class ProjectConstants {
    public static final String PREF_NAME = "login";
//    public static final String INTRO_SCREEN = "INTRO_SCREEN";
    public static final String IS_LOGIN = "IS_LOGIN";
    public static final String USER_NUM = "USER_NUM";
    public static final String USER_EMAIL = "USER_EMAIL";
    public static final String RECENT_ELDER = "RECENT_ELDER";
}
